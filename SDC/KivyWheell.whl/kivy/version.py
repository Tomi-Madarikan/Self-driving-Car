# THIS FILE IS GENERATED FROM KIVY SETUP.PY
__version__ = '1.11.0.dev0'
__hash__ = 'a95212d647528c2cc5ee95ff44616fb4029043c8'
__date__ = '20180806'
